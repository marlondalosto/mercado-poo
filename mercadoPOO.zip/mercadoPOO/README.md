# Mercado POO
Atividade avaliatiava da disciplina de Programação Orientada a Objetos proposta pelo professor Ítalo Dombrowski Machado.

## Objetivo
Desenvolver um sistema utilizando técnicas de programação orientada a objetos.

O sistema escolhido para ser desenvolvido é um sistema adminisitrativo para um mercado cujas vendas
são online, esse mesmo mercado também não possui uma loja física e somente faz envios.

_(O mercado em questão é apenas um cliente imaginário)_

### Instruções de Instalação
- Programas necessários
  - XAMPP (PHP 8.1.6 ou superior) https://www.apachefriends.org/download.html
  - Composer https://getcomposer.org/Composer-Setup.exe
- Instalar dependências do Laravel
```
cd mercadoPOO
composer i
```

### Instruções de Uso
- Inicializar o XAMPP

    ![](RECURSOS/XAMPP.png)
- Inicializar o arquivo ```start.bat```