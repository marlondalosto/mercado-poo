@extends('nav')

@section('main')
    <h1>Detalhes do pedido</h1>
        <div class="class table-responsive" id="tab">
            <table class="table table-hover">
                <thead class="thead-dark"><tr>
                    <th scope="col">Nome</th>
                    <th scope="col">Quantidade</th>
                    <th scope="col">Valor unitário</th>
                    <th scope="col">Subtotal</th>
                </tr></thead>
                <tbody>
                    @foreach($produtos as $prod)<tr>
                        <td class="linha" scope="row">{{ $prod['nome'] }}</td>
                        <td class="linha" scope="row">{{ $prod['qtde'] }}</td>
                        <td class="linha" scope="row">R${{ $prod['valor'] }}</td>
                        <td>R${{ number_format($prod['subtotal'],2,",",".") }}</td>
                    </tr>@endforeach
                </tbody>
            </table>
        </div>
    <h2 name="total">Total: R${{ number_format($total,2,",",".") }}</h2>
    <h1>Entrega</h1>
    <p>As mercadorias devem ser retiradas aqui no mercado!</p>
    <h1>Forma de pagamento</h1>
@stop

@section('form')
    <form action="{{ route('confPag') }}" method="post">
        @csrf
        <div class="form">
            <input type="text" name="prod" value="{{json_encode($produtos)}}" hidden>
            <input type="number" name="total" value="{{$total}}" hidden>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="pag" id="Cartão de crédito" value="Cartão de crédito" checked>
            <label class="form-check-label" for="exampleRadios1">
                Cartão de crédito
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="pag" id="Cartão de débito" value="Cartão de débito">
            <label class="form-check-label" for="exampleRadios2">
                Cartão de débito
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="pag" id="Pix" value="Pix">
            <label class="form-check-label" for="exampleRadios3">
                Pix
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="pag" id="Boleto" value="Boleto">
            <label class="form-check-label" for="exampleRadios4">
                Boleto
            </label>
        </div>
        <button type="submit" class="btn btn-success" name="confPag">Confirmar compra</button>
    </form>
    <a href="{{route('viewCarrinho')}}">Voltar ao carrinho</a>
@endsection
