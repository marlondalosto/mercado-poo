@extends('nav')

@section('main')
    <h1>Parabéns pela ótima compra!</h1>

    <p>Muito obrigado por comprar conosco!</p>

    <p>Avisaremos quando seu pedido pode ser retirado aqui no mercado.</p>

    <a href="{{route('index')}}">Voltar à página inicial</a>
@endsection
