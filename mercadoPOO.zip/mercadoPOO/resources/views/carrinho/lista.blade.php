@extends('nav')

@section('lista')
    <div class="row">

        <table class="table table-striped" style="text-align: center">
            <thead>
                <tr>
                    <th scope="col">Nome</th>
                    <th scope="col">Quantidade</th>
                    <th scope="col">Preço Unitário</th>
                    <th scope="col">Ações</th>
                </tr>
            </thead>
            <tbody>

                @foreach ($produtos as $produto)
                    <tr>
                        <th class="linha" scope="row">{{ $produto['nome'] }}</th>
                        <td class="linha">{{ $produto['qtd'] }}</td>
                        <td class="linha">R$ {{ $produto['valor'] }}</td>
                        <td style="text-align:center">
                            <form action='{{ route('dellCarrinho', ['id_carrinho' => $produto['id_linha']]) }}'>
                                <button type="submit" class="btn btn-danger">Retirar do Carrinho</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
                <tr>
                    @if ($total <= 0)
                        <th colspan="4"> Não tem Produtos no carrinho</th>
                    @else
                        <th class="linha"scope="row">Custo Total</th>
                        <td class="linha" scope="row"></td>
                        <td class="linha" scope="row">R$ {{ $total }}</td>
                        <td scope="row">
                            <form action='{{route('comprar')}}' method="post">
                                @csrf
                                <input type="text" name='total' value="{{$total}}" hidden>
                                <input type="text" name="ls" value="{{json_encode($produtos)}}" hidden>
                                <button type="submit" class="btn btn-success">Comprar</button>
                            </form>
                        </td>
                    @endif
                </tr>
            </tbody>
        </table>
    </div>
    
@endsection
