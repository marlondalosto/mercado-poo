@extends('nav')

@section('form')
    <br><br>
    <div class="container">

        <form method="post" action="{{ route('cadUsuarioBack') }}">
            @csrf
            <div class="row">
                <div class="col">
                    <input name="nome" type="text" class="form-control" placeholder="Nome">
                </div>

            </div><br>
            <div class="row">
                <div class="col">
                    <input name="email" type="email" class="form-control" placeholder="Endereço de E-mail">
                </div>
                <div class="col">
                    <input name="senha" type="password" class="form-control" placeholder="Senha">
                </div>
            </div><br>

            <div class="row">
                <div class="col">
                    <input oninput="mascara(this)" name="cpf" type="text" class="form-control" placeholder="CPF">
                </div>
            </div><br>
            <div class="row">
                <div class="col" style="text-align: center">
                    <button type="submit" class="btn btn-success">Cadastrar</button>
                </div>
            </div>
        </form>
    </div>
    <script>
        function mascara(i) {

            var v = i.value;

            if (isNaN(v[v.length - 1])) { // impede entrar outro caractere que não seja número
                i.value = v.substring(0, v.length - 1);
                return;
            }

            i.setAttribute("maxlength", "14");
            if (v.length == 3 || v.length == 7) i.value += ".";
            if (v.length == 11) i.value += "-";

        }
    </script>
@endsection
