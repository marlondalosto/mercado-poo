@extends('nav')

@section('form')
    <br><br>
    <div class="container">
        <div class="row">
            <div class="col-sm-5 m-auto">
                <form method="post" action='{{ route('usuarioLogin') }}'>
                    @csrf

                    <div class="mb-4">
                        <input type="email" name='email' placeholder="Endereço de E-mail" class="form-control" />

                    </div>


                    <div class=" mb-4">
                        <input name='senha' type="password" placeholder="Senha" class="form-control" />

                    </div>


                    <div class="row mb-4">
                        <div class="col d-flex justify-content-center">

                            <div class="">
                                <input class="form-check-input" type="checkbox" value="" id="form2Example31"
                                    checked />
                                <label class="form-check-label" for="form2Example31"> Lembrem-se de mim </label>
                            </div>
                        </div>


                    </div>


                    <button type="submit" class="btn btn-success  btn-block mb-4">Login</button>


                    <div class="text-center">
                        <p>Não tem conta? <a href="{{ route('usuarioForm') }}">Registre-se</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
