@extends('nav')

@section('form')
    <br><br>
    <div class="container">

        <form method="post" action="{{ route('cadProdutoBack') }}">
            @csrf
            <div class="row">
                <div class="col">
                    <input name="nome" type="text" class="form-control" placeholder="Nome">
                </div>

            </div><br>
            <div class="row">
                <div class="col">
                    <input name="valor" type="number" min="1" class="form-control" placeholder="Preço">
                </div>
                <div class="col">
                    <input name="quantidade" type="number" min="0" class="form-control" placeholder="Quantidade">
                </div>
            </div><br>

            <div class="row">
                <div class="col">
                    <select class="form-control" name="genero">
                        <option>Gênero</option>
                        @foreach ($generos as $gen)
                            <option value="{{ $gen->id }}">{{ $gen->nome }}</option>
                        @endforeach
                    </select>
                </div>
            </div><br>

            <div class="row">
                <div class="col">
                    <label for="exampleFormControlTextarea1">Descrição</label>
                    <textarea name="descricao" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>
            </div><br>
            <div class="row">
                <div class="col" style="text-align: center">
                    <button type="sbumit" class="btn btn-success">Cadastrar</button>
                </div>
            </div>
        </form>
    </div>
@endsection