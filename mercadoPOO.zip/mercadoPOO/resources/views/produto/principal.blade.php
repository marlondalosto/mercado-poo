@extends('nav')

@section('lista')
    <br><br>
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-12 col-sm-12 col-xl-12 col-md-12">
                <h1>Produtos</h1>
            </div>
        </div>
        <br><br>

        <div class="row">
        @foreach ($produtos as $produto)
                <div class="col-sm-4">
                    @if ( in_array($produto->genero_id, $listaPromocoes) )
                    <div class="card border-success mb-3">
                    @else
                    <div class="card mb-3">
                    @endif
                        <div class="card-body">
                            @if ( in_array($produto->genero_id, $listaPromocoes) )
                            <div class="card-header">
                                <h6>PROMOÇÃO</h6>
                            </div>
                            @endif
                            <h4 class="card-title">{{ $produto->nome }}</h>
                            @if ( in_array($produto->genero_id, $listaPromocoes) )
                            <h5 class="card-title text-success"> <s> De R$ {{ number_format($produto->valor, 2, ',', '') }} </s> por R$ {{ number_format($produto->valor - ($produto->valor * ($promocoes[$produto->genero_id] / 100)), 2, ',', '') }}</h5>
                            @else
                            <h5 class="card-title"> R$ {{ number_format($produto->valor, 2, ',', '') }}</h5>
                            @endif
                            
                            <p class="card-text">{{ $produto->descricao }}.</p>
                            <form class="d-flex" action="{{route('addCarrinho',['id_produto' => $produto->id, 'qtd' => 1])}}">
                                <button class="d-flex btn btn-success" type="submit"> Comprar </button>
                            </form>
                        </div>
                    </div>
                    <br>
                </div>
        @endforeach
        </div>
    </div>
@endsection
