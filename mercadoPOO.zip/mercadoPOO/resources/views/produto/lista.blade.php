@extends('nav')

@section('lista')
    <br><br>
    @if ($errors->any())
        {{ implode('', $errors->all(':message')) }}
    @endif
    <table class="table table-sm">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Valor</th>
                <th>Quantidade</th>
                <th>Gênero</th>
                <th>Editar</th>
                <th>Remover</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($produtos as $produto)
                <tr>
                    <td>@php print_r($produto->id) @endphp</td>
                    <td>@php print_r($produto->nome) @endphp</td>
                    <td>@php print_r($produto->descricao) @endphp</td>
                    <td>@php print_r($produto->valor) @endphp</td>
                    <td>@php print_r($produto->quantidade) @endphp</td>
                    <td>@php print_r($produto->genero_nome) @endphp</td>
                    <td><button type="button" class="btn btn-primary" data-toggle="modal"
                            data-target='#produtoEditar?{{ $produto->id }}'>Editar</button></td>
                    <td><button type="button" class="btn btn-danger" data-toggle="modal"
                            data-target='#produtoRemover?{{ $produto->id }}'>Remover</button></td>
                </tr>

                <!-- Modal editar produto -->
                <div class="modal fade" id="produtoEditar?{{ $produto->id }}" tabindex="-1" role="dialog"
                    aria-labelledby="#produtoRemoverTitle?{{ $produto->id }}" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Editar produto</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form method="post" action="{{ route('editarProduto') }}">
                                    @csrf
                                    <div class="row">
                                        <div class="col">
                                            <input name="produto_nome" value="{{ $produto->nome }}" type="text"
                                                class="form-control" placeholder="{{ $produto->nome }}">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col">
                                            <input name="produto_valor" value="{{ $produto->valor }}" type="number"
                                                min="1" class="form-control" placeholder="{{ $produto->valor }}">
                                        </div>
                                        <div class="col">
                                            <input name="produto_quantidade" value="{{ $produto->quantidade }}"
                                                type="number" min="0" class="form-control"
                                                placeholder="{{ $produto->quantidade }}">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col">
                                            <select class="form-control" name="produto_genero_id">
                                                <option value="{{ $produto->genero_id }}">{{ $produto->genero_nome }}
                                                </option>
                                                @foreach ($generos as $genero)
                                                    @if ($produto->genero_id != $genero->id)
                                                        <option value="{{ $genero->id }}">{{ $genero->nome }}</option>
                                                    @endif
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col">
                                            <textarea class="form-control" name="produto_descricao" value="{{ $produto->descricao }}">{{ $produto->descricao }}</textarea>
                                        </div>
                                    </div>
                                    <input type="hidden" name="produto_id" value="{{ $produto->id }}"></input>
                                    <br>
                                    <div class="d-flex justify-content-center">
                                        <button type="submit" class="btn btn-success">Editar</button>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Voltar</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal excluir produto -->
                <div class="modal fade" id="produtoRemover?{{ $produto->id }}" tabindex="-1" role="dialog"
                    aria-labelledby="#produtoRemoverTitle?{{ $produto->id }}" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Você deseja remover o produto
                                    {{ $produto->nome }}?</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form method="post" action="{{ route('removerProduto') }}">
                                    @csrf
                                    <input type="hidden" name="produto_id" value="{{ $produto->id }}"></input>
                                    <div class="d-flex justify-content-center">
                                        <button type="submit" class="btn btn-danger">Sim</button>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Não</button>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </tbody>
    </table>
@endsection
