<!DOCTYPE html>
<html>

<head>
    <title>Mercado Frankenstein</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>

    <style>
        main{
            text-align: center;
        }
        #tab{
            width: 50%;
            margin: auto;
        }
    </style>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">

        {{-- Botão Home --}}
        <a class="navbar-brand" href="{{ route('index') }}">Mercado Frankenstein</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        {{-- Container do menu --}}
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">

                {{-- Dropdown de Produtos --}}
                <li class="nav-item dropdown" style="padding-left: 15px;">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:white">
                        Produtos </a>
                    {{-- Opções do Dropdown de Produtos --}}
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        @if (Auth::check() && (Auth::user()->tipo == 2 || Auth::user()->tipo == 3))
                            <a class="dropdown-item" href="{{ route('produtoViewAdmin') }}">Ver tabela</a>
                            <a class="dropdown-item" href="{{ route('produtoForm') }}">Cadastrar</a>
                        @endif
                    </div>
                </li>

                {{-- Dropdown de Promoções --}}
                <li class="nav-item dropdown" style="padding-left: 15px;">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:white">
                        Promoções </a>
                    {{-- Opções do Dropdown de Promoções --}}
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        @if (Auth::check() && (Auth::user()->tipo == 2 || Auth::user()->tipo == 3))
                            <a class="dropdown-item" href="{{ route('promocoesForm') }}"> Cadastrar </a>
                            <a class="dropdown-item" href="#">Editar</a>
                        @endif
                        <a class="dropdown-item" href="{{ route('promocoesView') }}"> Ver </a>
                    </div>
                </li>

                {{-- Dropdown de Usuarios --}}
                @if (Auth::check() && Auth::user()->tipo == 2)
                    <li class="nav-item dropdown" style="padding-left: 15px;">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:white">
                            Usuários </a>
                        {{-- Opções do Dropdown de Usuarios --}}
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ route('usuarioFormTwo') }}"> Cadastrar </a>
                            <a class="dropdown-item" href="#"> Editar </a>
                        </div>
                    </li>
                @endif
                {{-- Dropdown de Fornecedores --}}
                @if (Auth::check() && (Auth::user()->tipo == 2 || Auth::user()->tipo == 3))
                    <li class="nav-item dropdown">
                        <a style="color:white" class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Fornecedores </a>
                        {{-- Opções do Dropdown de Fornecedores --}}
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            @if (Auth::check() && (Auth::user()->tipo == 2 || Auth::user()->tipo == 3))
                                <a class="dropdown-item" href="{{ route('fornecedorView') }}">Ver</a>
                            @endif
                            @if (Auth::check() && Auth::user()->tipo == 2)
                                <a class="dropdown-item" href="{{ route('fornecedorForm') }}">Cadastrar</a>
                                <a class="dropdown-item" href="{{ route('estoqueForm') }}">Cadastrar Estoque</a>
                                <a class="dropdown-item" href="{{ route('estoqueView') }}">Ver Estoque</a>
                            @endif
                        </div>
                    </li>
                @endif

                {{-- Login e Cadastro --}}
                @if (Auth::check())
                    <li class="nav-item" style="padding-left: 15px;">
                        <span class="navbar-text" style="color:white">
                            {{ Auth::user()->nome }}
                        </span>
                    </li>
                    <form class="d-flex" action="{{ route('viewCarrinho') }}" style="padding-left: 15px;">
                        <button class="btn btn-success" type="submit"> <svg xmlns="http://www.w3.org/2000/svg"
                                width="16" height="16" fill="currentColor" class="bi bi-cart"
                                viewBox="0 0 16 16" a href=>
                                <path
                                    d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
                            </svg> Carrinho </button>

                    </form>
                    <form class="d-flex" action="{{ route('usuarioLogout') }}" style="padding-left: 15px;">
                        <button class="btn btn-danger" type="submit"> Sair </button>
                    </form>
                @else
                    <form class="d-flex" action="{{ route('usuarioFormLogin') }}" style="padding-left: 15px;">
                        <button class="btn btn-light" type="submit"> Login </button>
                    </form>

                    <form class="d-flex" action="{{ route('usuarioForm') }}" style="padding-left: 15px;">
                        <button class="btn btn-light" type="submit"> Cadastro </button>
                    </form>
                @endif
            </ul>
        </div>
    </nav>
    <main>
        <section class="main">
            @yield('main')
        </section>
        <div class="container">
            @yield('form')
            @yield('lista')
        </div>
    </main>
</body>

</html>
