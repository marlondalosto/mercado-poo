@extends('nav')

@section('lista')
    <br><br>
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-12 col-sm-12 col-xl-12 col-md-12">
                <h1>Promoções</h1>
            </div>
        </div>
        <br><br>

        <div class="row">
            @foreach ($promocoes as $promocao)
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Promoção de {{ $promocao->genero->nome }}</h5>
                            <p class="card-text">Aproveite nossa promoção do setor de {{ $promocao->genero->nome }}.
                                {{ number_format($promocao->percentual) }}% de desconto em qualquer produto do setor.</p>
                            <a href="#" class="btn btn-success">Ver Produtos</a>
                        </div>
                        <div class="card-footer text-muted">Termino em
                            {{ \Carbon\Carbon::parse($promocao->data_fim)->format('d/m/Y') }}</div>
                    </div>
                    <br>
                </div>
            @endforeach
        </div>
        <style>
            .page-item.active .page-link {
                background-color: #6c757d;
                border-color: #6c757d;
            }

            .page-item.disabled .page-link {
                color: #b1b6bc;
            }

            .page-link {
                color: #6c757d;
            }

            .page-link:hover {
                color: #565e64;
            }
        </style>
        {{ $promocoes->links() }}
    </div>
@endsection
