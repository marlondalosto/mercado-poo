@extends('nav')

@section('form')
    <br><br>
    <div class="container">

        <form method="post" action="{{ route('cadPromocaoBack') }}">
            @csrf
            <div class="row">
                <div class="col">
                    <select class="form-control" name="genero_id">
                        <option>Genero</option>
                        @foreach ($genero as $gen)
                            <option value="{{ $gen->id }}">{{ $gen->nome }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col">
                    <input name="percentual" type="number" min="1" class="form-control" placeholder="Porcentagem Disconto">
                </div>
            </div><br>
            <div class="row">
                <div class="col">
                    <label>Data de Inicio</label>
                    <input name="data_inicio" type="date" class="form-control">
                </div>
                <div class="col">
                    <label>Data de Terminio</label>
                    <input name="data_fim" type="date" class="form-control">
                </div>
            </div>
    </div><br>
    <div class="row">
        <div class="col" style="text-align: center">
            <button type="submit" class="btn btn-success">Cadastrar</button>
        </div>
    </div>
    </form>
    </div>
@endsection