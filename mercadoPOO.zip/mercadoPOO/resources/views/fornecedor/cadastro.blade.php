@extends('nav')

@section('form')
    <br><br>
    <div class="container">

        <form method="post" action="{{ route('cadFornecedorBack') }}">
            @csrf
            <div class="row">
                <div class="col">
                    <input name="nome" type="text" class="form-control" placeholder="Nome">
                </div>

            </div><br>
            <div class="row">
                <div class="col" style="text-align: center">
                    <button type="sbumit" class="btn btn-success">Cadastrar</button>
                </div>
            </div>
        </form>
    </div>
@endsection