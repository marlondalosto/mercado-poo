@extends('nav')

@section('lista')
@if($errors->any())
    {{ implode('', $errors->all(':message')) }}
@endif
    <table class="table table-sm">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nome</th>
            </tr>
        </thead>
        <tbody>
        @foreach ($fornecedores as $fornecedor)
            <tr>
                <td>@php print_r($fornecedor->id) @endphp</td>
                <td>@php print_r($fornecedor->nome) @endphp</td>
                <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target='#fornecedorEditar?{{ $fornecedor->id }}'>Editar</button></td>
                <td><button type="button" class="btn btn-danger" data-toggle="modal" data-target='#fornecedorRemover?{{ $fornecedor->id }}'>Remover</button></td>
            </tr>

            <!-- Modal editar fornecedor -->
            <div class="modal fade" id="fornecedorEditar?{{ $fornecedor->id }}" tabindex="-1" role="dialog" aria-labelledby="#fornecedorRemoverTitle?{{ $fornecedor->id }}" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Editar fornecedor</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="{{ route('editFornecedor') }}">
                            @csrf
                            <div class="row">
                                <div class="col">
                                    <input name="fornecedor_nome" value="{{ $fornecedor->nome }}" type="text" class="form-control" placeholder="{{ $fornecedor->nome }}">
                                </div>
                            </div>
                            <br>
                            <input type="hidden" name="fornecedor_id" value="{{ $fornecedor->id }}"></input>
                            <br>
                            <div class="d-flex justify-content-center">
                                <button type="submit" class="btn btn-success">Editar</button>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Voltar</button>
                    </div>
                    </div>
                </div>
            </div>

            <!-- Modal excluir fornecedor -->
            <div class="modal fade" id="fornecedorRemover?{{ $fornecedor->id }}" tabindex="-1" role="dialog" aria-labelledby="#fornecedorRemoverTitle?{{ $fornecedor->id }}" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Você deseja remover o fornecedor {{ $fornecedor->nome }}?</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="{{ route('removFornecedor') }}">
                            @csrf
                            <input type="hidden" name="fornecedor_id" value="{{ $fornecedor->id }}"></input>
                            <div class="d-flex justify-content-center">
                                <button type="submit" class="btn btn-danger">Sim</button>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Não</button>
                    </div>
                    </div>
                </div>
            </div>
        @endforeach
        </tbody>
    </table>
@endsection