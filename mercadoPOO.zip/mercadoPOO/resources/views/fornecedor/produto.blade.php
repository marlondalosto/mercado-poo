@extends('nav')

@section('lista')
@if($errors->any())
    {{ implode('', $errors->all(':message')) }}
@endif
    <table class="table table-sm">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Valor</th>
                <th>Quantidade</th>
                <th>Fornecedor</th>
                <th>Editar</th>
                <th>Remover</th>
            </tr>
        </thead>
        <tbody>
        @foreach ($estoque_fornecedor as $estoque)
            <tr>
                <td>@php print_r($estoque->id) @endphp</td>
                <td>@php print_r($estoque->nome) @endphp</td>
                <td>@php print_r($estoque->descricao) @endphp</td>
                <td>@php print_r($estoque->valor) @endphp</td>
                <td>@php print_r($estoque->quantidade) @endphp</td>
                <td>@php print_r($estoque->fornecedor_id) @endphp</td>
                <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target='#estoqueEditar?{{ $estoque->id }}'>Editar</button></td>
                <td><button type="button" class="btn btn-danger" data-toggle="modal" data-target='#estoqueRemover?{{ $estoque->id }}'>Remover</button></td>
            </tr>

            <!-- Modal editar produto do estoque -->
            <div class="modal fade" id="estoqueEditar?{{ $estoque->id }}" tabindex="-1" role="dialog" aria-labelledby="#estoqueRemoverTitle?{{ $estoque->id }}" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Editar estoque</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="{{ route('editEstoque') }}">
                            @csrf
                            <div class="row">
                                <div class="col">
                                    <input name="estoque_nome" value="{{ $estoque->nome }}" type="text" class="form-control" placeholder="{{ $estoque->nome }}">
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col">
                                    <input name="estoque_valor" value="{{ $estoque->valor }}" type="number" min="1" class="form-control" placeholder="{{ $estoque->valor }}">
                                </div>
                                <div class="col">
                                    <input name="estoque_quantidade" value="{{ $estoque->quantidade }}" type="number" min="0" class="form-control" placeholder="{{ $estoque->quantidade }}">
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col">
                                    <textarea class="form-control" name="estoque_descricao" value="{{ $estoque->descricao }}">{{ $estoque->descricao }}</textarea>
                                </div>
                            </div>
                            <input type="hidden" name="estoque_id" value="{{ $estoque->id }}">
                            <br>
                            <input type="hidden" name="fornecedor_id" value="{{ $estoque->fornecedor_id }}">
                            <br>
                            <div class="d-flex justify-content-center">
                                <button type="submit" class="btn btn-success">Editar</button>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Voltar</button>
                    </div>
                    </div>
                </div>
            </div>

            <!-- Modal excluir estoque -->
            <div class="modal fade" id="estoqueRemover?{{ $estoque->id }}" tabindex="-1" role="dialog" aria-labelledby="#estoqueRemoverTitle?{{ $estoque->id }}" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Você deseja remover o estoque {{ $estoque->nome }}?</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="{{ route('removEstoque') }}">
                            @csrf
                            <input type="hidden" name="estoque_id" value="{{ $estoque->id }}">
                            <div class="d-flex justify-content-center">
                                <button type="submit" class="btn btn-danger">Sim</button>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Não</button>
                    </div>
                    </div>
                </div>
            </div>
        @endforeach
        </tbody>
    </table>
@endsection