<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('compra_fornecedores_pagamentos', function (Blueprint $table) {
            $table->foreignId('pagamento_id')->constrained('pagamentos');
            $table->foreignId('compra_fornecedores_id')->constrained('compra_fornecedores');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('compra_fornecedores_pagamentos');
    }
};
