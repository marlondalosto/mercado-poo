<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('compra_fornecedores', function (Blueprint $table) {
            $table->id();
            $table->decimal('total', 10, 2);
            $table->foreignId('estoque_fornecedor_produto_id')->constrained('estoque_fornecedor');
            $table->timestampsTz();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('compra_fornecedores');
    }
};
