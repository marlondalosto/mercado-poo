<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Usuario;

class UsuarioSeeder extends Seeder
{
    public function run()
    {
        // Insere o gerente dentro do banco de dados
        $usuario = new Usuario();
        $usuario->nome = "Gerente";
        $usuario->email = "Gerente@gmail.com";
        $usuario->cpf = "041.975.600-01";
        $usuario->senha = bcrypt("teste123");
        $usuario->tipo = 2;
        $usuario->save();

        // Insere um funcionário dentro do banco de dados
        $usuario = new Usuario();
        $usuario->nome = "Funcinário";
        $usuario->email = "func@gmail.com";
        $usuario->cpf = "000.000.000-00";
        $usuario->senha = bcrypt("teste123");
        $usuario->tipo = 3;
        $usuario->save();

        // Inicializa o faker para ser usado com valores 'brasileiros'
        $faker = \Faker\Factory::create('pt_BR');

        // Gera 8 funcionários
        for ($i=0; $i < 9; $i++) { 
            $usuario = new Usuario();
            $usuario->nome = $faker->name;
            $usuario->email = $faker->email;
            $usuario->cpf = $faker->cpf;
            $usuario->senha = bcrypt(123);
            $usuario->tipo = 3;
            $usuario->save();
        }

        // Gera 40 usuários
        for ($i=0; $i < 40; $i++) { 
            $usuario = new Usuario();
            $usuario->nome = $faker->name;
            $usuario->email = $faker->email;
            $usuario->cpf = $faker->cpf;
            $usuario->senha = bcrypt(123);
            $usuario->tipo = 1;
            $usuario->save();
        }
    }
}
