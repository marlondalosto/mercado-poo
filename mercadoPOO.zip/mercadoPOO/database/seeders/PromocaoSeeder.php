<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Promocoes;
use Carbon\Carbon;

class PromocaoSeeder extends Seeder
{
    public function run()
    {
        // Inicializa o faker
        $faker = \Faker\Factory::create();

        // Insere promoções para o dia de hoje
        for ($i=0; $i < $faker->numberBetween(1, 6); $i++) { 
            $promocao = new Promocoes();
            $promocao->data_inicio = Carbon::today();
            $promocao->data_fim = Carbon::today();
            $promocao->percentual = $faker->numberBetween(5, 75);
            $promocao->genero_id = $faker->unique()->numberBetween(1, 6);
            $promocao->save();
        }
    }
}
