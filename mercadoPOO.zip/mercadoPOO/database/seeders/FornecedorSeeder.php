<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Fornecedor;

class FornecedorSeeder extends Seeder
{
    public function run()
    {
        // Inicializa o faker para ser usado com valores 'brasileiros'
        $faker = \Faker\Factory::create('pt_BR');

        // Gera 10 fornecedores
        for ($i=0; $i < 10; $i++) { 
            $fornecedor = new Fornecedor();
            $fornecedor->nome = $faker->company;
            $fornecedor->save();
        }
    }
}
