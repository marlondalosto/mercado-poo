<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Genero;

class GeneroSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $genero1 = new Genero();
        $genero1->nome = "Carnes";
        $genero1->save();
        $genero2 = new Genero();
        $genero2->nome = "Frutas";
        $genero2->save();
        $genero3 = new Genero();
        $genero3->nome = "Peixes";
        $genero3->save();
        $genero4 = new Genero();
        $genero4->nome = "Limpeza";
        $genero4->save();
        $genero5 = new Genero();
        $genero5->nome = "Laticíneos";
        $genero5->save();
        $genero6 = new Genero();
        $genero6->nome = "Móveis";
        $genero6->save();
    }
}
