<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        // Invoca todos os geradore ou 'seeders'
        $this->call(GeneroSeeder::class);
        $this->call(UsuarioSeeder::class);
        $this->call(PromocaoSeeder::class);
        $this->call(ProdutoSeeder::class);
        $this->call(FornecedorSeeder::class);
    }
}
