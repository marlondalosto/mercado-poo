<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Produto;

class ProdutoSeeder extends Seeder
{
    public static $nomesCarnes = [
        'Coxão de Fora',
        'Coxão de Dentro',
        'Linguiça',
        'Carne Moida',
        'Carne Desmoida',
        'Língua',
        'Picanha',
        'Alcatra',
        'Peito de Frango',
        'Coxa e Sobrecoxa',
        'Tiranossauro Pré-Frito'
    ];

    public static $nomesFrutas = [
        'Maçã',
        'Banana',
        'Abacate',
        'Laranja',
        'Kiwi',
        'Berinjela',
        'Limão',
        'Pera',
        'Ameixa',
        'Mamão do Himalaia',
        'Fruto de Azatoth'
    ];

    public static $nomesPeixes = [
        'Lambari',
        'Dourado',
        'Salmão',
        'Kraken das Profundezas do Abismo',
        'Tentáculos de Cthulhu'
    ];

    public static $nomesLimpeza = [
        'Remove Tudo',
        'Limpa Completo',
        'Tira Sujeira',
        'Esbranquiçador',
        'Cheirinho de Casa',
        'Hmmm Produto de Limpeza Genérico'
    ];

    public static $nomesLaticineos = [
        'Queijo',
        'Queijo de Leite',
        'Queijo de Vaca',
        'Queijo de Cabra',
        'Queijo de Queijo',
        'Leite',
        'Leite bem Leite',
        'Leite não-tão Leite',
        'Um Abacaxi Disfarçado'
    ];

    public static $nomesMoveis = [
        'Abajur',
        'Lava-Louças',
        'Cadeira Elétrica',
        'Relógio do Batman',
        'Impressora 3D',
        'Suporte para Necronomicon',
        'Caixão 4-Portas',
        'Cadeira Gamer não-tão Gamer',
        'Mesa da Discordia (não confundir com Discord)',
        'Parede Inquebrável que se Quebrou',
        'Bloco de Terra (do minecraft)'
    ];

    public function run()
    {
        // Inicializa o faker para ser usado com valores 'brasileiros'
        $faker = \Faker\Factory::create('pt_BR');

        // Gerador de carnes
        for ($i=0; $i < count(self::$nomesCarnes); $i++) { 
            $produto = new Produto();
            $produto->nome = self::$nomesCarnes[$i];
            $produto->descricao = $faker->text();
            $produto->valor = $faker->numberBetween(20, 500);
            $produto->quantidade = $faker->numberBetween(10, 100);
            $produto->genero_id = 1;
            $produto->save();
        }

        // Gerador de frutas
        for ($i=0; $i < count(self::$nomesFrutas); $i++) { 
            $produto = new Produto();
            $produto->nome = self::$nomesFrutas[$i];
            $produto->descricao = $faker->text();
            $produto->valor = $faker->numberBetween(1, 10);
            $produto->quantidade = $faker->numberBetween(100, 1000);
            $produto->genero_id = 2;
            $produto->save();
        }

        // Gerador de peixes
        for ($i=0; $i < count(self::$nomesPeixes); $i++) { 
            $produto = new Produto();
            $produto->nome = self::$nomesPeixes[$i];
            $produto->descricao = $faker->text();
            $produto->valor = $faker->numberBetween(50, 5000);
            $produto->quantidade = $faker->numberBetween(66, 666);
            $produto->genero_id = 3;
            $produto->save();
        }

        // Gerador de produtos de limpeza
        for ($i=0; $i < count(self::$nomesLimpeza); $i++) { 
            $produto = new Produto();
            $produto->nome = self::$nomesLimpeza[$i];
            $produto->descricao = $faker->text();
            $produto->valor = $faker->numberBetween(10, 50);
            $produto->quantidade = $faker->numberBetween(100, 300);
            $produto->genero_id = 4;
            $produto->save();
        }

        // Gerador de laticineos
        for ($i=0; $i < count(self::$nomesLaticineos); $i++) { 
            $produto = new Produto();
            $produto->nome = self::$nomesLaticineos[$i];
            $produto->descricao = $faker->text();
            $produto->valor = $faker->numberBetween(10, 50);
            $produto->quantidade = $faker->numberBetween(1, 999);
            $produto->genero_id = 5;
            $produto->save();
        }

        // geradocr de móveis
        for ($i=0; $i < count(self::$nomesMoveis); $i++) { 
            $produto = new Produto();
            $produto->nome = self::$nomesMoveis[$i];
            $produto->descricao = $faker->text();
            $produto->valor = $faker->numberBetween(399, 5000);
            $produto->quantidade = $faker->numberBetween(0, 20);
            $produto->genero_id = 6;
            $produto->save();
        }
    }
}
