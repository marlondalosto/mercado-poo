<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Produto;
use App\Models\ProdutoCompra;
use App\Models\Compra;
use PhpParser\Node\Expr\Cast\Object_;

class CompraController extends Controller
{
    function baixarNaTabelaProdutosCompras(Request $request, int $usuario_id){
        foreach(json_decode($request->input('prod')) as $prod){

            $bd_prod = DB::table('produtos')->where('nome', strval($prod->nome))->first();
            $prod_id = $bd_prod->id;

            $bd_compra = DB::table('compras')->where('usuario_id', $usuario_id)->orderBy('created_at', 'desc')->first();
            $id_compra = $bd_compra->id;

            $prodCompra = new ProdutoCompra();
            $prodCompra->subtotal = $prod->subtotal;
            $prodCompra->produto_id = $prod_id;
            $prodCompra->compra_id = $id_compra;
            $prodCompra->save();
            $this->ajustarTabelaProdutos($prod);
        }
    }

    function finalizarCompra(Request $request){
        if($request != null){
            $usuario_id = Auth::user()->id;
            $compra = new Compra();
            $compra->total = $request->input('total');
            $compra->usuario_id = $usuario_id;
            $compra->forma_pagamento = $request->input('pag');
            $compra->save();
            $this->baixarNaTabelaProdutosCompras($request, $usuario_id);
            return view('compra.CompraRealizada');
        }
    }

    function ajustarTabelaProdutos(Object $prod){
        $bd_prod = DB::table('produtos')->where('nome', strval($prod->nome))->first();
        $prod_qtde = $bd_prod->quantidade;
        $prod_id = $bd_prod->id;
        $ajusteQtde = $prod_qtde - $prod->qtde;
        DB::update('update produtos set quantidade = '.$ajusteQtde.' where id = ?', [$prod_id]);
    }

    function viewPagamento(Request $produtos){
        $produtos_compra = [];
        foreach(json_decode($produtos->input('ls')) as $prod){

            array_push($produtos_compra, [
                'id_linha' => $prod->id_linha,
                'nome' => $prod->nome,
                'descricao' => $prod->descricao,
                'valor' => $prod->valor,
                'qtde' => $prod->qtd,
                'subtotal' => $prod->qtd * $prod->valor
            ]);
        }

        return view('compra.fecharCompra', ['produtos' => $produtos_compra, 'total' => $produtos->input('total')]);
    }
}
