<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Produto;
use App\Models\Promocoes;
use App\Models\Genero;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

use Carbon\Carbon;

class ProdutoController extends Controller
{
    public function produtoFormView() {
        if (Auth::check() && Auth::user()->tipo == 2) {
            $generos = Genero::all();
            $generos->toArray();
            return view('produto.cadastro', ['generos' => $generos]);
        } else {
            return redirect()->route('usuarioFormLogin');
        }
    }

    public function cadastraProduto(Request $request) {
        $rules = [
            'nome' => 'required',
            'descricao' => 'required',
            'valor' => 'required',
            'quantidade' => 'required',
            'genero' => 'required'
        ];
        $this->validate($request, $rules);
        $produto = new Produto();
        $produto->nome = $request->input('nome');
        $produto->descricao = $request->input('descricao');
        $produto->valor = $request->input('valor');
        $produto->quantidade = $request->input('quantidade');
        $produto->genero_id = $request->input('genero');
        $produto->save();
        return redirect()->route('produtoForm');
    }

    public function produtoView() {
        if (!Auth::check() || Auth::user()->tipo != 2) {
            return redirect()->route('usuarioFormLogin');
        }

        $produtos = DB::table('produtos')
            ->select('produtos.id', 'produtos.nome', 'produtos.descricao', 'produtos.valor', 'produtos.quantidade', 'produtos.genero_id', 'generos.nome as genero_nome')
            ->join('generos', 'generos.id', '=', 'produtos.genero_id')
            ->orderBy('produtos.id', 'desc')
            ->get();

        $generos = Genero::all();
        return view('produto.lista', [
            'produtos' => $produtos,
            'generos' => $generos
        ]);
    }

    public function editarProduto(Request $request)
    {
        if (!Auth::check() || Auth::user()->tipo != 2) {
            return redirect()->route('usuarioFormLogin');
        }

        if (empty($request->produto_id) || $request->produto_id == NULL) {
            return Redirect::back();
        }

        $edita = DB::table('produtos')
                    ->where('produtos.id', '=', $request->produto_id)
                    ->update([
                        'produtos.nome' => $request->produto_nome,
                        'produtos.descricao' => $request->produto_descricao,
                        'produtos.valor' => $request->produto_valor,
                        'produtos.quantidade' => $request->produto_quantidade,
                        'produtos.genero_id' => $request->produto_genero_id
                    ]);
    
        if (!$edita) {
            $error = [
                'Erro ao editar produto'
            ];
            return Redirect::back()->withErrors($error);
        }

        return Redirect::back();
    }

    public function removerProduto(Request $request)
    {
        if (!Auth::check() || Auth::user()->tipo != 2) {
            return redirect()->route('usuarioFormLogin');
        }

        if (empty($request->produto_id) || $request->produto_id == NULL) {
            $error = [
                'produto_id vazio ou null.'
            ];
            return Redirect::back()->withErrors($error);
        }

        if (DB::table('produtos')->where('produtos.id', '=', $request->produto_id)->doesntExist()) {
            $error = [
                'Produto não existe.'
            ];
            return Redirect::back()->withErrors($error);
        }

        $remove = DB::table('produtos')
                    ->where('produtos.id', '=', $request->produto_id)
                    ->delete();

        if (!$remove) {
            $error = [
                'Erro ao remover produto'
            ];
            return Redirect::back()->withErrors($error);
        }
        return Redirect::back();
    }

    public function principal()
    {
        $today = Carbon::now();
        $produtos = Produto::all();
        $promocoesConsulta = Promocoes::query()
            ->whereDate('data_inicio', '<=', $today)
            ->whereDate('data_fim', '>=', $today)
            ->paginate(6);

        $listaPromocoes = [];
        $promocoes = [];
        foreach ($promocoesConsulta as $promocao)
        {
            array_push($listaPromocoes, $promocao->genero_id);
            $promocoes[$promocao->genero_id] = $promocao->percentual;
        }
        return view('produto.principal')->with('produtos', $produtos)->with('listaPromocoes', $listaPromocoes)->with('promocoes', $promocoes);
    }
}
