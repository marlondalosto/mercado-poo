<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Usuario;

use Illuminate\Support\Facades\Auth;

class UsuarioController extends Controller
{
    public function usuarioFormView()
    {
        return view('usuario.autoCadastro');
    }
    public function UsuarioFormViewTwo()
    {
        if (Auth::check() && Auth::user()->tipo == 2) {
            return view('usuario.cadastro');
        } else {
            return redirect()->route('usuarioFormLogin');
        }
    }
    public function cadastraUsuario(Request $request)
    {
        $rules = [
            'nome' => 'required',
            'email' => 'required',
            'senha' => 'required',
            'cpf' => 'required',
        ];
        $this->validate($request, $rules);
        $usuario = new Usuario();
        $usuario->nome = $request->input('nome');
        $usuario->email = $request->input('email');
        $usuario->cpf = $request->input('cpf');
        $usuario->senha = bcrypt($request->input('senha'));
        if ($request->input('tipo')) {
            $usuario->tipo = $request->input('tipo');
        } else {
            $usuario->tipo = 1;
        }
        $usuario->save();
        return redirect()->route('usuarioForm');
    }
    public function usuarioFormLoginView()
    {
        return view('usuario.login');
    }

    
    public function destroy($id){
        if('tipo' != 2){
            return view('usuario.cadastro');
        }
        else {
            $usuario = Usuario::find($id);
            $usuario->delete();
 	    return 'removido';
        }   
    }

}
