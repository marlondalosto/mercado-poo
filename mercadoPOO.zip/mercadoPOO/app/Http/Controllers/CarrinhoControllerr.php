<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

use App\Models\Carrinho;

use Illuminate\Support\Facades\DB;

use App\Models\Produto;

class CarrinhoControllerr extends Controller
{



    public function viewCarrinho()
    {
        if (Auth::check()) {


            $carrinho = Carrinho::where('usuario_id', Auth::user()->id)->get();
            $carrinho->toArray();
            $produtos_carrinho = [];
            $total = 0;
            foreach ($carrinho as $gen) {
                $bp = Produto::find($gen->produto_id);

                array_push($produtos_carrinho, [
                    'id_linha' => $gen->id,
                    'nome' => $bp->nome,
                    'descricao' => $bp->descricao,
                    'valor' => floatval($bp->valor),
                    'qtd' => $gen->quantidade
                ]);

                $total += ($gen->quantidade * $bp->valor);
            }

            return view('carrinho.lista', ['produtos' => $produtos_carrinho, 'total' => $total]);
        } else {
            return redirect()->route('index');
        }
    }

    public function addCarrinho(Request $request)
    {
        $id_produto = $request->id_produto;
        $qtd = $request->qtd;
        $id_usuario =  Auth::user()->id;
        if ($id_produto && $qtd && $id_usuario && $id_usuario) {
            $carrinho = new Carrinho();
            $carrinho->produto_id = $id_produto;
            $carrinho->usuario_id = $id_usuario;
            $carrinho->quantidade = $qtd;
            $carrinho->save();
        }

        return redirect()->route('viewCarrinho');
    }

    public function dellCarrinho(Request $request)
    {
        $id_carrinho = $request->id_carrinho;
        $id_usuario =  Auth::user()->id;
        DB::table('carrinhos')->where('id', $id_carrinho)->where('usuario_id', $id_usuario)->delete();


        return redirect()->route('viewCarrinho');
    }
}
