<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;

use App\Models\Genero;

use App\Models\Promocoes;

use Illuminate\Support\Facades\Auth;

use Illuminate\Database\Eloquent\Model;

class PromocoesController extends Controller
{
    public function promocoesFormView()
    {
        if (Auth::check() && Auth::user()->tipo == 2) {
            $genero = Genero::all();
            $genero->toArray();
            return view('promocao.cadastro', ['genero' => $genero]);
        } else {
            return redirect()->route('usuarioFormLogin');
        }
    }
    public function cadastraPromocao(Request $request)
    {
        $rules = [
            'genero_id' => 'required',
            'percentual' => 'required',
            'data_inicio' => 'required',
            'data_fim' => 'required'
        ];
        $this->validate($request, $rules);
        $promocao = new Promocoes();
        $promocao->create($request->all());
        return redirect()->route('promocoesForm');
    }

    public function promocoesView()
    {
        $today = Carbon::now();
        $promocoes = Promocoes::with('genero')
            ->whereDate('data_inicio', '<=', $today)
            ->whereDate('data_fim', '>=', $today)
            ->paginate(6);
        return view('promocao.lista')->with('promocoes',$promocoes);
    }

}
