<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Compra;

class EstatisticasController extends Controller
{
    public function estatisticasView()
    {
        $compras = Compra::query();
        return view('estatisticas.grafico');
    }
}
