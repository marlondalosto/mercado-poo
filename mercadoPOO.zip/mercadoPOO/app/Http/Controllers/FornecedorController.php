<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Fornecedor;

use App\Models\EstoqueFornecedor;

use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Redirect;

use Illuminate\Support\Facades\DB;

class FornecedorController extends Controller
{
    public function cadastraFornecedorFormView()
    {
        if (!Auth::check() || Auth::user()->tipo != 2) {
            return redirect()->route('usuarioFormLogin');
        }
        return view('fornecedor.cadastro');
    }
    public function cadastraFornecedor(Request $request)
    {
        if (!Auth::check() || Auth::user()->tipo != 2) {
            return redirect()->route('usuarioFormLogin');
        }
        $rules = [
            'nome' => 'required',
        ];
        $this->validate($request, $rules);
        $fornecedor = new Fornecedor();
        $fornecedor->nome = $request->input('nome');
        $fornecedor->save();
        return redirect()->route('fornecedorForm');
    }
    public function fornecedorView()
    {
        $fornecedor = DB::table('fornecedores')
            ->select('fornecedores.id', 'fornecedores.nome')
            ->orderBy('fornecedores.id', 'desc')
            ->get();
        return view('fornecedor.lista', ['fornecedores' => $fornecedor]);
    }
    public function editarFornecedor(Request $request)
    {
        if (!Auth::check() || (Auth::user()->tipo != 2 && Auth::user()->tipo != 3)) {
            return redirect()->route('usuarioFormLogin');
        }

        if (empty($request->fornecedor_id) || $request->fornecedor_id == NULL) {
            return Redirect::back();
        }

        $edita = DB::table('fornecedores')
            ->where('fornecedores.id', '=', $request->fornecedor_id)
            ->update([
                'fornecedores.nome' => $request->fornecedor_nome,
            ]);

        if (!$edita) {
            $error = [
                'Erro ao editar fornecedor'
            ];
            return Redirect::back()->withErrors($error);
        }

        return Redirect::back();
    }
    public function removerFornecedor(Request $request)
    {
        if (!Auth::check() || Auth::user()->tipo != 2) {
            return redirect()->route('usuarioFormLogin');
        }

        if (empty($request->fornecedor_id) || $request->fornecedor_id == NULL) {
            $error = [
                'fornecedor_id vazio ou null.'
            ];
            return Redirect::back()->withErrors($error);
        }

        if (DB::table('fornecedores')->where('fornecedores.id', '=', $request->fornecedor_id)->doesntExist()) {
            $error = [
                'Fornecedor não existe.'
            ];
            return Redirect::back()->withErrors($error);
        }

        $remove = DB::table('fornecedores')
            ->where('fornecedores.id', '=', $request->fornecedor_id)
            ->delete();

        if (!$remove) {
            $error = [
                'Erro ao remover fornecedor'
            ];
            return Redirect::back()->withErrors($error);
        }
        return Redirect::back();
    }
    /*---------------------------------------Estoque Fornecedor------------------------------------------*/

    public function cadastraEstoqueFornecedorFormView()
    {
        if (!Auth::check() || Auth::user()->tipo != 2) {
            return redirect()->route('usuarioFormLogin');
        }
        return view('fornecedor.cadEstoque');
    }
    public function cadastraEstoqueFornecedor(Request $request)
    {
        if (!Auth::check() || Auth::user()->tipo != 2) {
            return redirect()->route('usuarioFormLogin');
        }
        $rules = [
            'nome' => 'required',
            'descricao' => 'required',
            'valor' => 'required',
            'quantidade' => 'required',
            'id' => 'required'
        ];
        $this->validate($request, $rules);
        $estoque = new EstoqueFornecedor();
        $estoque->nome = $request->input('nome');
        $estoque->descricao = $request->input('descricao');
        $estoque->valor = $request->input('valor');
        $estoque->quantidade = $request->input('quantidade');
        $estoque->fornecedor_id = $request->input('id');
        $estoque->save();
        return redirect()->route('estoqueForm');
    }
    public function estoqueFornecedorView()
    {
        $estoque =  EstoqueFornecedor::all();
        return view('fornecedor.produto', ['estoque_fornecedor' => $estoque]);
    }
    public function editarEstoqueFornecedor(Request $request)
    {
        if (!Auth::check() || Auth::user()->tipo != 2) {
            return redirect()->route('usuarioFormLogin');
        }

        if (empty($request->estoque_id) || $request->estoque_id == NULL) {
            return Redirect::back();
        }

        $edita = DB::table('estoque_fornecedor')
            ->where('estoque_fornecedor.id', '=', $request->estoque_id)
            ->update([
                'estoque_fornecedor.nome' => $request->estoque_nome,
                'estoque_fornecedor.descricao' => $request->estoque_descricao,
                'estoque_fornecedor.valor' => $request->estoque_valor,
                'estoque_fornecedor.quantidade' => $request->estoque_quantidade,
            ]);

        if (!$edita) {
            $error = [
                'Erro ao editar produto'
            ];
            return Redirect::back()->withErrors($error);
        }

        return Redirect::back();
    }
    public function removerEstoqueFornecedor(Request $request)
    {
        if (!Auth::check() || Auth::user()->tipo != 2) {
            return redirect()->route('usuarioFormLogin');
        }

        if (empty($request->estoque_id) || $request->estoque_id == NULL) {
            $error = [
                'estoque_id vazio ou null.'
            ];
            return Redirect::back()->withErrors($error);
        }

        if (DB::table('estoque_fornecedor')->where('estoque_fornecedor.id', '=', $request->estoque_id)->doesntExist()) {
            $error = [
                'Produto não existe.'
            ];
            return Redirect::back()->withErrors($error);
        }

        $remove = DB::table('estoque_fornecedor')
            ->where('estoque_fornecedor.id', '=', $request->estoque_id)
            ->delete();

        if (!$remove) {
            $error = [
                'Erro ao remover produto'
            ];
            return Redirect::back()->withErrors($error);
        }
        return Redirect::back();
    }
}
