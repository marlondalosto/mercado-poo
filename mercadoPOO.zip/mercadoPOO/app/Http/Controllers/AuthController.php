<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

use App\Models\Usuario;

use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $request->validate(['email' => 'required', 'senha' => 'required']);
        $usuario = Usuario::where('email', $request->input('email'))->first();
        if (!empty($usuario) && Hash::check($request->senha, $usuario->senha)) {
            Auth::loginUsingId($usuario->id);
            return redirect()->route('index');
        }
    }
    public function logout()
    {
        Auth::logout();
        return redirect()->route('index');
    }
}
