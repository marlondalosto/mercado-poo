<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Promocoes extends Model
{
    use HasFactory;
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'data_inicio',
        'data_fim',
        'percentual',
        'genero_id',
    ];

    public function genero()
    {
        return $this->BelongsTo(Genero::class);
    }
}
