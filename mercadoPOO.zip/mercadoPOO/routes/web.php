<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [\App\Http\Controllers\ProdutoController::class, 'principal'])->name('index');


Route::prefix('/carrinho')->group(function () {

    Route::get('/ver', [\App\Http\Controllers\CarrinhoControllerr::class, 'viewCarrinho'])->name('viewCarrinho');
    Route::get('/add/{id_produto}/{qtd}', [\App\Http\Controllers\CarrinhoControllerr::class, 'addCarrinho'])->name('addCarrinho');
    Route::get('/dell/{id_carrinho}', [\App\Http\Controllers\CarrinhoControllerr::class, 'dellCarrinho'])->name('dellCarrinho');
});

Route::POST('/compra', [\App\Http\Controllers\CompraController::class, 'viewPagamento'])->name('comprar');

Route::POST('/compra-finalizada', [\App\Http\Controllers\CompraController::class, 'finalizarCompra'])->name('confPag');


Route::prefix('/produto')->group(function () {
    Route::get('/cadastro', [\App\Http\Controllers\ProdutoController::class, 'produtoFormView'])->name('produtoForm');
    Route::post('/editar', [\App\Http\Controllers\ProdutoController::class, 'editarProduto'])->name('editarProduto');
    Route::post('/remover', [\App\Http\Controllers\ProdutoController::class, 'removerProduto'])->name('removerProduto');
    Route::POST('/cadastroBackEnd', [\App\Http\Controllers\ProdutoController::class, 'cadastraProduto'])->name('cadProdutoBack');
    Route::get('/verProdutos', [\App\Http\Controllers\ProdutoController::class, 'produtoView'])->name('produtoViewAdmin');
});

Route::prefix('/promocoes')->group(function () {
    Route::get('/cadastro', [\App\Http\Controllers\PromocoesController::class, 'promocoesFormView'])->name('promocoesForm');
    Route::POST('/cadastroBackEnd', [\App\Http\Controllers\PromocoesController::class, 'cadastraPromocao'])->name('cadPromocaoBack');
    Route::get('/verPromocoes', [\App\Http\Controllers\PromocoesController::class, 'promocoesView'])->name('promocoesView');
});

Route::prefix('/usuario')->group(function () {
    Route::get('/autocadastro', [\App\Http\Controllers\UsuarioController::class, 'usuarioFormView'])->name('usuarioForm');
    Route::get('/cadastro', [\App\Http\Controllers\UsuarioController::class, 'UsuarioFormViewTwo'])->name('usuarioFormTwo');
    Route::POST('/cadastroBackEnd', [\App\Http\Controllers\UsuarioController::class, 'cadastraUsuario'])->name('cadUsuarioBack');
    Route::get('/login', [\App\Http\Controllers\UsuarioController::class, 'usuarioFormLoginView'])->name('usuarioFormLogin');
    Route::POST('/loginBackEnd', [\App\Http\Controllers\AuthController::class, 'login'])->name('usuarioLogin');
    Route::get('/logout', [\App\Http\Controllers\AuthController::class, 'logout'])->name('usuarioLogout');
    Route::delete('/delete/{id}', [\App\Http\Controllers\UsuarioController::class, 'destroy'])->name('usuariodestroy');

});

Route::prefix('/fornecedor')->group(function () {
    Route::get('/cadastro', [\App\Http\Controllers\FornecedorController::class, 'cadastraFornecedorFormView'])->name('fornecedorForm');
    Route::post('/cadastroBackEnd', [\App\Http\Controllers\FornecedorController::class, 'cadastraFornecedor'])->name('cadFornecedorBack');
    Route::post('/editar', [\App\Http\Controllers\FornecedorController::class, 'editarFornecedor'])->name('editFornecedor');
    Route::post('/remover', [\App\Http\Controllers\FornecedorController::class, 'removerFornecedor'])->name('removFornecedor');
    Route::get('/verFornecedor', [\App\Http\Controllers\FornecedorController::class, 'fornecedorView'])->name('fornecedorView');
});
Route::prefix('/estoque')->group(function () { 
    Route::get('/cadastro', [\App\Http\Controllers\FornecedorController::class, 'cadastraEstoqueFornecedorFormView'])->name('estoqueForm');
    Route::post('/cadastroBackEnd', [\App\Http\Controllers\FornecedorController::class, 'cadastraEstoqueFornecedor'])->name('cadEstoqueBack');
    Route::post('/editar', [\App\Http\Controllers\FornecedorController::class, 'editarEstoqueFornecedor'])->name('editEstoque');
    Route::post('/remover', [\App\Http\Controllers\FornecedorController::class, 'removerEstoqueFornecedor'])->name('removEstoque');
    Route::get('/verEstoque', [\App\Http\Controllers\FornecedorController::class, 'estoqueFornecedorView'])->name('estoqueView');
});

Route::prefix('/estatisticas')->group(function () {
    Route::get('/visualizar', [\App\Http\Controllers\EstatisticasController::class, 'estatisticasView'])->name('estatisticasView');
});